module.exports = (sequelize, Sequelize) => {
    const Quizscore = sequelize.define("quizscore", {
      QuizId: {
        type: Sequelize.INTEGER
      },
      UserId: {
        type: Sequelize.INTEGER
      },
      Score: {
        type: Sequelize.INTEGER
      }
     

    });
  
    return Quizscore;
  };
const express = require("express");
const db = require("./app/models");

const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();
require("./app/routes/tutorial.route.js")(app);
require("./app/routes/question.route.js")(app);
require("./app/routes/game.route.js")(app);
require("./app/routes/gameScore.route.js")(app);

var corsOptions = {
  origin: "http://localhost:8081"
};

app.use(cors(corsOptions));

// parse requests of content-type - application/json
app.use(bodyParser.json());
//app.use(express.json()); 

// parse requests of content-type - application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));



db.sequelize.sync();
// simple route
// app.get("/", (req, res) => {
//   res.json({ message: "Welcome to bezkoder application." });
// });


// set port, listen for requests
const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}.`);
});
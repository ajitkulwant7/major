module.exports = (sequelize, Sequelize) => {
    const Admin = sequelize.define("admin", {
    
      username: {
        type: Sequelize.STRING
      },
      password: {
        type: Sequelize.STRING
      }
     
    
    },
    {timestamps: false});
   
  
    return Admin;
  };